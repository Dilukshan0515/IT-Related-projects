import barcode
from barcode import Code128
def generate_barcode(data):
    code=Code128(data)
    code.save("Barcode")
    print("Barcode is generated")

data="0302-1527-2003"
generate_barcode(data)